"""Data ingestion helpers."""
