"""Shared utility helpers."""
