"""Common helpers."""
